import os
import shutil
import argparse
from tqdm import tqdm

def restore_dataset(input_dir, output_dir):
    """
    还原数据集结构：
    从: input_dir/类名/类名_序号.jpg
    到: output_dir/类名_序号.jpg
    """
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    # 收集所有图像文件
    image_files = []
    class_dirs = []
    
    # 遍历输入目录，查找所有子目录
    for item in os.listdir(input_dir):
        item_path = os.path.join(input_dir, item)
        if os.path.isdir(item_path):
            class_dirs.append(item)
            # 在每个类别目录中查找图像文件
            for filename in os.listdir(item_path):
                if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                    image_files.append((item, filename))
    
    if not image_files:
        print(f"在目录 {input_dir} 中没有找到图像文件")
        return
    
    print(f"找到 {len(class_dirs)} 个类别目录")
    print(f"找到 {len(image_files)} 个图像文件，开始还原...")
    
    # 创建进度条
    progress_bar = tqdm(total=len(image_files), desc="还原图像")
    
    # 统计信息
    class_count = {}
    moved_count = 0
    error_count = 0
    duplicate_count = 0
    
    # 处理每个文件
    for class_name, filename in image_files:
        try:
            # 源路径
            src_path = os.path.join(input_dir, class_name, filename)
            
            # 目标路径
            dest_path = os.path.join(output_dir, filename)
            
            # 检查目标文件是否已存在
            if os.path.exists(dest_path):
                print(f"\n警告: 文件 {filename} 在目标目录中已存在")
                # 为避免覆盖，添加类名前缀
                base_name, ext = os.path.splitext(filename)
                new_filename = f"{class_name}_{base_name}{ext}"
                dest_path = os.path.join(output_dir, new_filename)
                
                if os.path.exists(dest_path):
                    print(f"重命名后的文件 {new_filename} 仍然存在，跳过")
                    duplicate_count += 1
                    progress_bar.update(1)
                    continue
                    
                print(f"重命名为: {new_filename}")
            
            # 验证源文件存在
            if not os.path.exists(src_path):
                print(f"\n错误: 源文件 {src_path} 不存在")
                error_count += 1
                progress_bar.update(1)
                continue
            
            # 移动文件
            shutil.move(src_path, dest_path)
            
            # 更新统计
            class_count[class_name] = class_count.get(class_name, 0) + 1
            moved_count += 1
            
            # 更新进度条
            progress_bar.update(1)
            
        except Exception as e:
            print(f"\n处理 {class_name}/{filename} 时出错: {str(e)}")
            error_count += 1
            progress_bar.update(1)
    
    # 关闭进度条
    progress_bar.close()
    
    # 清理空目录
    print("\n清理空目录...")
    removed_dirs = 0
    for class_name in class_dirs:
        class_dir = os.path.join(input_dir, class_name)
        try:
            if os.path.exists(class_dir) and not os.listdir(class_dir):
                os.rmdir(class_dir)
                removed_dirs += 1
        except Exception as e:
            print(f"无法删除目录 {class_dir}: {str(e)}")
    
    # 打印摘要
    print("\n" + "=" * 50)
    print(f"还原完成!")
    print(f"总处理文件: {len(image_files)}")
    print(f"成功移动: {moved_count}")
    print(f"错误文件: {error_count}")
    print(f"重复文件: {duplicate_count}")
    print(f"处理的类别数: {len(class_count)}")
    print(f"删除的空目录: {removed_dirs}")
    
    # 显示类别统计
    print("\n类别统计 (前20个):")
    sorted_classes = sorted(class_count.items(), key=lambda x: x[1], reverse=True)
    for i, (cls, count) in enumerate(sorted_classes[:20]):
        print(f"  {i+1}. {cls}: {count} 张图片")
    
    if len(sorted_classes) > 20:
        print(f"  显示前20个类别，共有 {len(sorted_classes)} 个类别")
    
    print("=" * 50)

def verify_restoration(output_dir):
    """
    验证还原结果
    """
    print("\n验证还原结果...")
    
    # 统计文件
    all_files = [f for f in os.listdir(output_dir) 
                 if os.path.isfile(os.path.join(output_dir, f))]
    
    image_files = [f for f in all_files 
                   if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    
    # 分析文件名格式
    correct_format = 0
    incorrect_format = 0
    
    for filename in image_files:
        if '_' in filename:
            correct_format += 1
        else:
            incorrect_format += 1
    
    print(f"总文件数: {len(all_files)}")
    print(f"图像文件数: {len(image_files)}")
    print(f"正确格式 (包含'_'): {correct_format}")
    print(f"异常格式: {incorrect_format}")
    
    # 检查是否有子目录
    subdirs = [d for d in os.listdir(output_dir) 
               if os.path.isdir(os.path.join(output_dir, d))]
    
    if subdirs:
        print(f"\n警告: 输出目录中存在 {len(subdirs)} 个子目录:")
        for d in subdirs[:5]:
            print(f"  - {d}")
        if len(subdirs) > 5:
            print(f"  ... 还有 {len(subdirs) - 5} 个")

if __name__ == "__main__":
    # 设置命令行参数
    parser = argparse.ArgumentParser(description='还原数据集结构到扁平形式')
    parser.add_argument('--input', type=str, default='./dataset/wildfish', 
                       help='输入目录 (包含分类后的图像文件)')
    parser.add_argument('--output', type=str, default='./dataset/wildfish_restored', 
                       help='输出目录 (还原后的扁平结构)')
    parser.add_argument('--verify', action='store_true', 
                       help='还原后验证结果')
    
    args = parser.parse_args()
    
    # 检查输入目录是否存在
    if not os.path.exists(args.input):
        print(f"错误: 输入目录 {args.input} 不存在!")
        exit(1)
    
    # 执行还原
    print(f"开始还原数据集...")
    print(f"输入目录: {args.input}")
    print(f"输出目录: {args.output}")
    
    restore_dataset(args.input, args.output)
    
    # 验证结果
    if args.verify:
        verify_restoration(args.output)
    
    # 最终提示
    print("\n提示: 还原完成后，您可以使用以下命令验证结果:")
    print(f"  ls {args.output} | head -20  # 查看文件列表")
    print(f"  ls {args.output} | wc -l  # 统计文件总数")
    print(f"  ls -la {args.output} | grep '^d' | wc -l  # 检查是否有子目录")
    print("\n如需验证还原结果，可以运行:")
    print(f"  python restore_dataset.py --input {args.input} --output {args.output} --verify")