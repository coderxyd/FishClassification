def find_images_and_targets_wildfish(root, dataset, istrain=False, aux_info=False):
    """
    为wildfish数据集加载图像、标签和元信息
    支持训练集/验证集划分，并加载鱼类描述信息
    """
    import json
    import torch
    from sentence_transformers import SentenceTransformer
    
    images_and_targets = []
    images_info = []
    
    # 获取所有类别文件夹
    class_folders = [d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))]
    class_to_idx = {cls: idx for idx, cls in enumerate(sorted(class_folders))}
    
    # 加载鱼类描述信息
    descriptions_path = os.path.join(root, 'fish_descriptions.json')
    fish_descriptions = {}
    if os.path.exists(descriptions_path):
        with open(descriptions_path, 'r', encoding='utf-8') as f:
            fish_descriptions = json.load(f)
    
    # 如果需要aux_info，初始化文本嵌入模型
    if aux_info:
        # 使用中文BERT模型来生成文本嵌入
        model = SentenceTransformer('sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2')
    
    # 设置固定的随机种子以确保可重复性
    np.random.seed(42)
    
    # 收集每个类别的所有图像
    class_images = {}
    total_images = 0
    min_samples_per_class = float('inf')
    
    for class_name in class_folders:
        class_path = os.path.join(root, class_name)
        target = class_to_idx[class_name]
        
        # 获取该类别下的所有图像
        images_in_class = []
        for img_name in os.listdir(class_path):
            if any(img_name.lower().endswith(ext) for ext in IMG_EXTENSIONS):
                img_path = os.path.join(class_path, img_name)
                images_in_class.append(img_path)
        
        if len(images_in_class) > 0:
            class_images[target] = (images_in_class, class_name)
            total_images += len(images_in_class)
            min_samples_per_class = min(min_samples_per_class, len(images_in_class))
        else:
            print(f"警告: 类别 {class_name} 没有找到任何图像")
    
    print(f"数据集统计: {len(class_images)}个类别, 总共{total_images}张图像")
    print(f"最少样本数的类别有{min_samples_per_class}张图像")
    
    # 对每个类别进行改进的划分
    train_count = 0
    val_count = 0
    classes_with_single_sample = 0
    
    for target, (img_paths, class_name) in class_images.items():
        # 随机打乱图像顺序
        img_paths_shuffled = np.array(img_paths)
        np.random.shuffle(img_paths_shuffled)
        
        n_total = len(img_paths_shuffled)
        
        # 获取该鱼类的描述信息
        fish_info = fish_descriptions.get(class_name, {})
        description = fish_info.get('description', f'{class_name}是一种鱼类。')
        
        # 如果需要aux_info，生成文本嵌入
        if aux_info:
            # 将所有相关信息组合成一个描述文本
            full_description = description
            if 'habitat' in fish_info:
                full_description += f" 栖息地：{fish_info['habitat']}。"
            if 'features' in fish_info:
                full_description += f" 特征：{'、'.join(fish_info['features'])}。"
            if 'size' in fish_info:
                full_description += f" 体长：{fish_info['size']}。"
            
            # 生成文本嵌入向量
            text_embedding = model.encode(full_description, convert_to_tensor=True)
            text_embedding = text_embedding.cpu().numpy()
        
        # 数据集划分逻辑（保持原有的划分策略）
        if n_total == 1:
            classes_with_single_sample += 1
            if istrain:
                selected_paths = img_paths_shuffled
            else:
                selected_paths = img_paths_shuffled
        elif n_total == 2:
            if istrain:
                selected_paths = img_paths_shuffled[:1]
            else:
                selected_paths = img_paths_shuffled[1:]
        else:
            if n_total <= 4:
                n_val = 1
                n_train = n_total - 1
            else:
                n_val = max(1, int(n_total * 0.2))
                n_train = n_total - n_val
            
            if istrain:
                selected_paths = img_paths_shuffled[:n_train]
            else:
                selected_paths = img_paths_shuffled[n_train:]
        
        # 将选中的图像添加到结果列表
        for img_path in selected_paths:
            if aux_info:
                images_and_targets.append([img_path, target, text_embedding])
                images_info.append({
                    'class_name': class_name,
                    'description': description,
                    'full_info': fish_info
                })
            else:
                images_and_targets.append([img_path, target])
        
        if istrain:
            train_count += len(selected_paths)
        else:
            val_count += len(selected_paths)
    
    # 统计信息输出
    if classes_with_single_sample > 0:
        print(f"注意: {classes_with_single_sample}个类别只有1张图像，将同时出现在训练集和验证集中")
    
    if istrain:
        print(f"Wildfish训练集: {len(images_and_targets)}张图像，{len(class_images)}个类别")
    else:
        print(f"Wildfish验证集: {len(images_and_targets)}张图像，{len(class_images)}个类别")
    
    # 验证所有类别都有样本
    actual_classes = set()
    for item in images_and_targets:
        target = item[1]
        actual_classes.add(target)
    
    if len(actual_classes) != len(class_images):
        missing_classes = set(class_images.keys()) - actual_classes
        print(f"错误: {'训练集' if istrain else '验证集'}中缺少以下类别: {missing_classes}")
    else:
        print(f"✓ 所有{len(class_images)}个类别都在{'训练集' if istrain else '验证集'}中有样本")
    
    return images_and_targets, class_to_idx, images_info