import json
import torch
import torch.nn as nn
import numpy as np
from collections import defaultdict
import re
from PIL import Image
from dataset_fg import DatasetMeta

class WildfishMetaEncoder:
    """
    将wildfish的JSON元信息编码成数值向量
    """
    def __init__(self, metadata_path):
        with open(metadata_path, 'r') as f:
            self.metadata = json.load(f)
        
        # 构建所有可能值的词汇表
        self.build_vocabularies()
        
        # 计算各部分的维度
        self.calculate_dimensions()
    
    def build_vocabularies(self):
        """构建所有类别特征的词汇表"""
        # 分类学词汇表
        self.taxonomy_vocabs = {
            'kingdom': set(),
            'phylum': set(),
            'class': set(),
            'order': set(),
            'family': set(),
            'genus': set(),
            'species': set()
        }
        
        # 视觉特征词汇表
        self.body_shapes = set()
        self.all_colors = set()
        self.color_patterns = set()
        self.eye_features = set()
        self.mouth_types = set()
        
        # 栖息地词汇表
        self.backgrounds = set()
        self.geographical_locations = set()
        
        # 遍历所有数据构建词汇表
        for fish_name, data in self.metadata.items():
            # 分类学信息
            taxonomy = data.get('taxonomy', {})
            for level, vocab_set in self.taxonomy_vocabs.items():
                if level in taxonomy:
                    vocab_set.add(taxonomy[level])
            
            # 视觉特征
            visual = data.get('visual_features', {})
            if 'body_shape' in visual:
                self.body_shapes.add(visual['body_shape'])
            if 'primary_colors' in visual:
                for color in visual['primary_colors']:
                    self.all_colors.add(color)
            if 'color_patterns' in visual:
                self.color_patterns.add(visual['color_patterns'])
            if 'eye_features' in visual:
                self.eye_features.add(visual['eye_features'])
            if 'mouth_type' in visual:
                self.mouth_types.add(visual['mouth_type'])
            
            # 栖息地信息
            habitat = data.get('habitat_appearance', {})
            if 'typical_background' in habitat:
                self.backgrounds.add(habitat['typical_background'])
            if 'geographical_distribution' in habitat:
                for location in habitat['geographical_distribution']:
                    self.geographical_locations.add(location)
        
        # 转换为索引映射
        self._build_index_mappings()
    
    def _build_index_mappings(self):
        """构建特征值到索引的映射"""
        # 分类学映射
        self.taxonomy_to_idx = {}
        for level, vocab in self.taxonomy_vocabs.items():
            self.taxonomy_to_idx[level] = {v: i+1 for i, v in enumerate(sorted(vocab))}  # 0留给unknown
        
        # 视觉特征映射
        self.body_shape_to_idx = {v: i+1 for i, v in enumerate(sorted(self.body_shapes))}
        self.color_to_idx = {v: i+1 for i, v in enumerate(sorted(self.all_colors))}
        self.pattern_to_idx = {v: i+1 for i, v in enumerate(sorted(self.color_patterns))}
        self.eye_to_idx = {v: i+1 for i, v in enumerate(sorted(self.eye_features))}
        self.mouth_to_idx = {v: i+1 for i, v in enumerate(sorted(self.mouth_types))}
        
        # 栖息地映射
        self.background_to_idx = {v: i+1 for i, v in enumerate(sorted(self.backgrounds))}
        self.location_to_idx = {v: i+1 for i, v in enumerate(sorted(self.geographical_locations))}
    
    def calculate_dimensions(self):
        """计算各部分的维度"""
        self.dims = {
            # 分类学维度
            'taxonomy': {
                level: len(vocab) + 1 for level, vocab in self.taxonomy_vocabs.items()
            },
            # 视觉特征维度
            'visual': {
                'body_shape': len(self.body_shapes) + 1,
                'colors': len(self.all_colors) + 1,
                'pattern': len(self.color_patterns) + 1,
                'eye': len(self.eye_features) + 1,
                'mouth': len(self.mouth_types) + 1,
                'size': 2  # min和max两个数值
            },
            # 栖息地维度
            'habitat': {
                'background': len(self.backgrounds) + 1,
                'location': len(self.geographical_locations) + 1,
                'depth': 2  # min和max两个数值
            }
        }
    
    def encode_fish_metadata(self, fish_name):
        """编码单个鱼类的元信息"""
        if fish_name not in self.metadata:
            raise ValueError(f"Fish {fish_name} not found in metadata")
        
        data = self.metadata[fish_name]
        
        # 1. 编码分类学信息
        taxonomy_indices = self._encode_taxonomy(data.get('taxonomy', {}))
        
        # 2. 编码视觉特征
        visual_indices = self._encode_visual_features(data.get('visual_features', {}))
        
        # 3. 编码栖息地信息
        habitat_indices = self._encode_habitat(data.get('habitat_appearance', {}))
        
        return {
            'taxonomy': taxonomy_indices,
            'visual': visual_indices,
            'habitat': habitat_indices
        }
    
    def _encode_taxonomy(self, taxonomy):
        """编码分类学信息"""
        indices = {}
        for level in self.taxonomy_vocabs.keys():
            if level in taxonomy:
                indices[level] = self.taxonomy_to_idx[level].get(taxonomy[level], 0)
            else:
                indices[level] = 0
        return indices
    
    def _encode_visual_features(self, visual):
        """编码视觉特征"""
        indices = {}
        
        # 体型
        indices['body_shape'] = self.body_shape_to_idx.get(visual.get('body_shape', ''), 0)
        
        # 颜色（多标签）
        color_indices = []
        for color in visual.get('primary_colors', []):
            idx = self.color_to_idx.get(color, 0)
            if idx > 0:
                color_indices.append(idx)
        indices['colors'] = color_indices if color_indices else [0]
        
        # 颜色模式
        indices['pattern'] = self.pattern_to_idx.get(visual.get('color_patterns', ''), 0)
        
        # 眼部特征
        indices['eye'] = self.eye_to_idx.get(visual.get('eye_features', ''), 0)
        
        # 嘴部类型
        indices['mouth'] = self.mouth_to_idx.get(visual.get('mouth_type', ''), 0)
        
        # 大小范围
        size_range = visual.get('size_range', '0-0 cm')
        sizes = self._parse_size_range(size_range)
        indices['size'] = sizes
        
        return indices
    
    def _encode_habitat(self, habitat):
        """编码栖息地信息"""
        indices = {}
        
        # 背景类型
        indices['background'] = self.background_to_idx.get(habitat.get('typical_background', ''), 0)
        
        # 地理分布（多标签）
        location_indices = []
        for location in habitat.get('geographical_distribution', []):
            idx = self.location_to_idx.get(location, 0)
            if idx > 0:
                location_indices.append(idx)
        indices['location'] = location_indices if location_indices else [0]
        
        # 深度范围
        depth_range = habitat.get('depth_range', '0-0 meters')
        depths = self._parse_depth_range(depth_range)
        indices['depth'] = depths
        
        return indices
    
    def _parse_size_range(self, size_str):
        """解析大小范围字符串，如 '10-12 cm' -> [10.0, 12.0]"""
        try:
            numbers = re.findall(r'\d+\.?\d*', size_str)
            if len(numbers) >= 2:
                return [float(numbers[0]), float(numbers[1])]
            elif len(numbers) == 1:
                return [float(numbers[0]), float(numbers[0])]
        except:
            pass
        return [0.0, 0.0]
    
    def _parse_depth_range(self, depth_str):
        """解析深度范围字符串，如 '5-15 meters' -> [5.0, 15.0]"""
        try:
            numbers = re.findall(r'\d+\.?\d*', depth_str)
            if len(numbers) >= 2:
                return [float(numbers[0]), float(numbers[1])]
            elif len(numbers) == 1:
                return [float(numbers[0]), float(numbers[0])]
        except:
            pass
        return [0.0, 0.0]


class WildfishMetaEmbedding(nn.Module):
    """
    将编码后的索引转换为可学习的embedding
    """
    def __init__(self, encoder, embedding_dim=32):
        super().__init__()
        self.encoder = encoder
        self.embedding_dim = embedding_dim
        
        # 创建embedding层
        self._create_embeddings()
        
        # 最终输出的维度
        self.output_dims = self._calculate_output_dims()
    
    def _create_embeddings(self):
        """创建所有的embedding层"""
        # 分类学embeddings
        self.taxonomy_embeddings = nn.ModuleDict()
        for level, vocab_size in self.encoder.dims['taxonomy'].items():
            self.taxonomy_embeddings[level] = nn.Embedding(
                vocab_size, self.embedding_dim, padding_idx=0
            )
        
        # 视觉特征embeddings
        self.visual_embeddings = nn.ModuleDict({
            'body_shape': nn.Embedding(self.encoder.dims['visual']['body_shape'], self.embedding_dim, padding_idx=0),
            'colors': nn.Embedding(self.encoder.dims['visual']['colors'], self.embedding_dim, padding_idx=0),
            'pattern': nn.Embedding(self.encoder.dims['visual']['pattern'], self.embedding_dim, padding_idx=0),
            'eye': nn.Embedding(self.encoder.dims['visual']['eye'], self.embedding_dim, padding_idx=0),
            'mouth': nn.Embedding(self.encoder.dims['visual']['mouth'], self.embedding_dim, padding_idx=0),
            'size': nn.Linear(2, self.embedding_dim)  # 数值特征用线性层
        })
        
        # 栖息地embeddings
        self.habitat_embeddings = nn.ModuleDict({
            'background': nn.Embedding(self.encoder.dims['habitat']['background'], self.embedding_dim, padding_idx=0),
            'location': nn.Embedding(self.encoder.dims['habitat']['location'], self.embedding_dim, padding_idx=0),
            'depth': nn.Linear(2, self.embedding_dim)  # 数值特征用线性层
        })
        
        # 特征融合层
        self.taxonomy_fusion = nn.Linear(7 * self.embedding_dim, self.embedding_dim * 3)  # 7个分类层级
        self.visual_fusion = nn.Linear(6 * self.embedding_dim, self.embedding_dim * 2)  # 6个视觉特征
        self.habitat_fusion = nn.Linear(3 * self.embedding_dim, self.embedding_dim)  # 3个栖息地特征
    
    def _calculate_output_dims(self):
        """计算最终输出维度"""
        return {
            'taxonomy': self.embedding_dim * 3,  # 150维
            'visual': self.embedding_dim * 2,     # 80维
            'habitat': self.embedding_dim         # 40维
        }
    
    def forward(self, fish_names):
        """
        前向传播
        Args:
            fish_names: list of fish names
        Returns:
            tensor of shape (batch_size, total_embedding_dim)
        """
        batch_size = len(fish_names)
        device = next(self.parameters()).device
        
        taxonomy_features = []
        visual_features = []
        habitat_features = []
        
        for fish_name in fish_names:
            # 获取编码后的索引
            encoded = self.encoder.encode_fish_metadata(fish_name)
            
            # 1. 处理分类学特征
            tax_embeds = []
            for level in ['kingdom', 'phylum', 'class', 'order', 'family', 'genus', 'species']:
                idx = torch.tensor([encoded['taxonomy'][level]], device=device)
                embed = self.taxonomy_embeddings[level](idx)
                tax_embeds.append(embed)
            tax_concat = torch.cat(tax_embeds, dim=1)
            tax_fused = self.taxonomy_fusion(tax_concat)
            taxonomy_features.append(tax_fused)
            
            # 2. 处理视觉特征
            vis_embeds = []
            # 单标签特征
            for feat in ['body_shape', 'pattern', 'eye', 'mouth']:
                idx = torch.tensor([encoded['visual'][feat]], device=device)
                embed = self.visual_embeddings[feat](idx)
                vis_embeds.append(embed)
            
            # 多标签特征（颜色）- 取平均
            color_indices = torch.tensor(encoded['visual']['colors'], device=device)
            color_embed = self.visual_embeddings['colors'](color_indices).mean(dim=0, keepdim=True)
            vis_embeds.append(color_embed)
            
            # 数值特征（大小）
            size_tensor = torch.tensor(encoded['visual']['size'], device=device, dtype=torch.float32)
            size_embed = self.visual_embeddings['size'](size_tensor).unsqueeze(0)
            vis_embeds.append(size_embed)
            
            vis_concat = torch.cat(vis_embeds, dim=1)
            vis_fused = self.visual_fusion(vis_concat)
            visual_features.append(vis_fused)
            
            # 3. 处理栖息地特征
            hab_embeds = []
            # 单标签特征
            bg_idx = torch.tensor([encoded['habitat']['background']], device=device)
            bg_embed = self.habitat_embeddings['background'](bg_idx)
            hab_embeds.append(bg_embed)
            
            # 多标签特征（地理位置）- 取平均
            loc_indices = torch.tensor(encoded['habitat']['location'], device=device)
            loc_embed = self.habitat_embeddings['location'](loc_indices).mean(dim=0, keepdim=True)
            hab_embeds.append(loc_embed)
            
            # 数值特征（深度）
            depth_tensor = torch.tensor(encoded['habitat']['depth'], device=device, dtype=torch.float32)
            depth_embed = self.habitat_embeddings['depth'](depth_tensor).unsqueeze(0)
            hab_embeds.append(depth_embed)
            
            hab_concat = torch.cat(hab_embeds, dim=1)
            hab_fused = self.habitat_fusion(hab_concat)
            habitat_features.append(hab_fused)
        
        # 批量化处理
        taxonomy_batch = torch.cat(taxonomy_features, dim=0)
        visual_batch = torch.cat(visual_features, dim=0)
        habitat_batch = torch.cat(habitat_features, dim=0)
        
        # 合并所有特征
        meta_features = torch.cat([taxonomy_batch, visual_batch, habitat_batch], dim=1)
        
        return meta_features


class WildfishMetaDataset(DatasetMeta):
    """
    Wildfish数据集，带有元信息
    """
    def __init__(self, root, transform=None, train=True, meta_json_path=None, embedding_dim=32):
        # 先初始化父类
        super().__init__(root, transform, train, aux_info=True, dataset='wildfish')
        
        # 初始化元信息编码器
        self.encoder = WildfishMetaEncoder(meta_json_path)
        self.meta_embedding = WildfishMetaEmbedding(self.encoder, embedding_dim)
        
        # 将embedding模型设为eval模式（如果不需要训练embedding）
        # self.meta_embedding.eval()
        
        # 计算总的元信息维度
        self.meta_dim = sum(self.meta_embedding.output_dims.values())
        print(f"Total meta dimension: {self.meta_dim}")
        print(f"  - Taxonomy: {self.meta_embedding.output_dims['taxonomy']}")
        print(f"  - Visual: {self.meta_embedding.output_dims['visual']}")
        print(f"  - Habitat: {self.meta_embedding.output_dims['habitat']}")
    
    def __getitem__(self, index):
        path, target = self.samples[index]
        img = Image.open(path).convert('RGB')
        
        # 从路径中提取类名
        class_name = path.split('/')[-2]
        
        # 获取元信息embedding
        with torch.no_grad():  # 如果不训练embedding
            meta_features = self.meta_embedding([class_name])
            meta_features = meta_features.squeeze(0).cpu().numpy()
        
        if self.transform is not None:
            img = self.transform(img)
        
        return img, target, meta_features
    
    def get_meta_dim(self):
        """返回元信息的总维度"""
        return self.meta_dim


# 使用示例
if __name__ == "__main__":
    # 测试编码器
    encoder = WildfishMetaEncoder('fish_metadata.json')
    
    # 查看词汇表大小
    print("Vocabulary sizes:")
    print(f"Body shapes: {len(encoder.body_shapes)}")
    print(f"Colors: {len(encoder.all_colors)}")
    print(f"Locations: {len(encoder.geographical_locations)}")
    
    # 测试编码
    encoded = encoder.encode_fish_metadata("Abactochromis_labrosus")
    print("\nEncoded metadata:", encoded)
    
    # 测试embedding模型
    embed_model = WildfishMetaEmbedding(encoder)
    features = embed_model(["Abactochromis_labrosus"])
    print(f"\nEmbedding shape: {features.shape}")