import os
import shutil
import argparse
from tqdm import tqdm
import re

def parse_filename(filename):
    """
    解析文件名，提取类名和序号
    假设格式为: 类名_序号.扩展名
    其中类名可能包含下划线
    """
    # 去掉扩展名
    name_without_ext = os.path.splitext(filename)[0]
    
    # 从后往前查找最后一个下划线后的部分
    # 假设序号部分是数字（可能包含其他字符如字母）
    parts = name_without_ext.split('_')
    
    # 尝试找到序号部分（从后往前查找第一个看起来像序号的部分）
    for i in range(len(parts)-1, 0, -1):
        # 检查这部分是否包含数字（通常序号会包含数字）
        if any(char.isdigit() for char in parts[i]):
            # 找到了可能的序号部分
            class_name = '_'.join(parts[:i])
            sequence_number = '_'.join(parts[i:])
            return class_name, sequence_number
    
    # 如果没有找到包含数字的部分，返回None
    return None, None

def reorganize_dataset(input_dir, output_dir):
    """
    重新组织数据集结构：
    从: input_dir/类名_序号.jpg
    到: output_dir/类名/类名_序号.jpg
    
    支持类名中包含下划线的情况
    """
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    # 获取所有图像文件
    image_files = [f for f in os.listdir(input_dir) 
                  if os.path.isfile(os.path.join(input_dir, f)) 
                  and f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    
    if not image_files:
        print(f"在目录 {input_dir} 中没有找到图像文件")
        return
    
    print(f"找到 {len(image_files)} 个图像文件，开始重组...")
    
    # 创建进度条
    progress_bar = tqdm(total=len(image_files), desc="处理图像")
    
    # 统计信息
    class_count = {}
    moved_count = 0
    error_count = 0
    ambiguous_files = []
    
    # 处理每个文件
    for filename in image_files:
        try:
            # 解析类名和序号
            class_name, sequence = parse_filename(filename)
            
            if class_name is None or not class_name:
                # 如果无法解析，尝试使用备用方法
                # 假设至少最后一个下划线后面是序号
                if '_' in filename:
                    name_without_ext = os.path.splitext(filename)[0]
                    last_underscore_idx = name_without_ext.rfind('_')
                    class_name = name_without_ext[:last_underscore_idx]
                    
                    if not class_name:
                        print(f"\n警告: 无法解析文件名 {filename}，跳过")
                        error_count += 1
                        ambiguous_files.append(filename)
                        progress_bar.update(1)
                        continue
                else:
                    print(f"\n警告: 文件名 {filename} 不包含下划线，跳过")
                    error_count += 1
                    ambiguous_files.append(filename)
                    progress_bar.update(1)
                    continue
            
            # 创建类目录
            class_dir = os.path.join(output_dir, class_name)
            os.makedirs(class_dir, exist_ok=True)
            
            # 目标路径
            dest_path = os.path.join(class_dir, filename)
            
            # 源路径
            src_path = os.path.join(input_dir, filename)
            
            # 检查目标文件是否已存在
            if os.path.exists(dest_path):
                print(f"\n警告: 目标文件 {dest_path} 已存在，跳过")
                error_count += 1
                progress_bar.update(1)
                continue
            
            # 移动文件
            shutil.move(src_path, dest_path)
            
            # 更新统计
            class_count[class_name] = class_count.get(class_name, 0) + 1
            moved_count += 1
            
            # 更新进度条
            progress_bar.update(1)
            
        except Exception as e:
            print(f"\n处理 {filename} 时出错: {str(e)}")
            error_count += 1
            ambiguous_files.append(filename)
            progress_bar.update(1)
    
    # 关闭进度条
    progress_bar.close()
    
    # 打印摘要
    print("\n" + "=" * 50)
    print(f"重组完成!")
    print(f"总处理文件: {len(image_files)}")
    print(f"成功移动: {moved_count}")
    print(f"错误文件: {error_count}")
    print(f"创建的类别数: {len(class_count)}")
    
    # 显示类别统计
    print("\n类别统计 (前20个):")
    sorted_classes = sorted(class_count.items(), key=lambda x: x[1], reverse=True)
    for i, (cls, count) in enumerate(sorted_classes[:20]):
        print(f"  {i+1}. {cls}: {count} 张图片")
    
    if len(sorted_classes) > 20:
        print(f"  ... 还有 {len(sorted_classes) - 20} 个类别")
        print(f"  共计 {len(sorted_classes)} 个类别")
    
    # 显示可能有问题的文件
    if ambiguous_files:
        print(f"\n可能需要手动检查的文件 ({len(ambiguous_files)} 个):")
        for f in ambiguous_files[:10]:
            print(f"  - {f}")
        if len(ambiguous_files) > 10:
            print(f"  ... 还有 {len(ambiguous_files) - 10} 个文件")
    
    print("=" * 50)

def test_parsing():
    """测试文件名解析功能"""
    test_cases = [
        "goldfish_001.jpg",
        "great_white_shark_001.jpg", 
        "clown_fish_123.jpg",
        "atlantic_bluefin_tuna_456.jpg",
        "red_snapper_a001.jpg",
        "king_salmon_test_789.jpg"
    ]
    
    print("测试文件名解析:")
    print("-" * 50)
    for filename in test_cases:
        class_name, seq = parse_filename(filename)
        print(f"文件名: {filename}")
        print(f"  -> 类名: {class_name}")
        print(f"  -> 序号: {seq}")
        print()

if __name__ == "__main__":
    # 设置命令行参数
    parser = argparse.ArgumentParser(description='重组数据集结构')
    parser.add_argument('--input', type=str, default='./dataset/wildfish_restored', 
                       help='输入目录 (包含原始图像文件)')
    parser.add_argument('--output', type=str, default='./dataset/wildfish', 
                       help='输出目录 (重组后的结构)')
    parser.add_argument('--test', action='store_true',
                       help='测试文件名解析功能')
    
    args = parser.parse_args()
    
    # 如果是测试模式
    if args.test:
        test_parsing()
        exit(0)
    
    # 检查输入目录是否存在
    if not os.path.exists(args.input):
        print(f"错误: 输入目录 {args.input} 不存在!")
        exit(1)
    
    # 执行重组
    print(f"开始重组数据集...")
    print(f"输入目录: {args.input}")
    print(f"输出目录: {args.output}")
    
    reorganize_dataset(args.input, args.output)
    
    # 最终提示
    print("\n提示: 重组完成后，您可以使用以下命令验证数据集结构:")
    print(f"  tree -d {args.output} | head -20  # 查看目录结构")
    print(f"  find {args.output} -type f | wc -l  # 统计文件总数")
    print("\n您可以首先运行测试来验证解析逻辑:")
    print(f"  python {os.path.basename(__file__)} --test")
    print("\n您可能需要更新训练脚本中的数据集路径:")
    print(f"  将 DATA.DATA_PATH 设置为: {args.output}")