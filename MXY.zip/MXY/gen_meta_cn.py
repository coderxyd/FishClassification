import os
import json
import time
from typing import Dict, List, Optional
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from openai import OpenAI
import logging

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class FishMetadataGenerator:
    def __init__(self, api_key: Optional[str] = None):
        """
        初始化DeepSeek API客户端
        
        Args:
            api_key: DeepSeek API密钥，如果不提供则从环境变量读取
        """
        # 优先使用传入的 API key，否则从环境变量读取
        self.api_key = api_key or os.getenv("DEEPSEEK_API_KEY")
        # self.api_key="sk-58398b171b744f1d8ab6eb3d9598fd15"
        if not self.api_key:
            raise ValueError(
                "API密钥未提供。请设置环境变量 DEEPSEEK_API_KEY 或在初始化时传入 api_key"
            )
        
        # 使用 OpenAI SDK
        self.client = OpenAI(
            api_key=self.api_key,
            base_url="https://api.deepseek.com"
        )
        
    def extract_fish_classes(self, dataset_path: str) -> List[str]:
        """
        从数据集目录中提取所有鱼类类别
        
        Args:
            dataset_path: 数据集根目录路径
            
        Returns:
            鱼类类别列表
        """
        fish_classes = []
        dataset_dir = Path(dataset_path)
        
        if not dataset_dir.exists():
            raise ValueError(f"数据集路径不存在: {dataset_path}")
            
        # 遍历所有子目录
        for item in dataset_dir.iterdir():
            if item.is_dir() and not item.name.startswith('.'):
                fish_classes.append(item.name)
                
        logger.info(f"在 {dataset_path} 中找到 {len(fish_classes)} 个类别")
        return sorted(fish_classes)
    
    def generate_prompt(self, fish_class: str) -> str:
        """
        生成用于获取鱼类元信息的提示词
        
        Args:
            fish_class: 鱼类类别名称（如 Abactochromis_labrosus）
            
        Returns:
            格式化的提示词
        """
        # 将下划线替换为空格，使其更易读
        readable_name = fish_class.replace('_', ' ')
        
        prompt = f"""请为鱼类 "{readable_name}" 生成详细的元信息，用于图像分类任务。请严格按照以下JSON格式返回：

{{
    "scientific_name": "{fish_class}",
    "common_name": "该鱼的常见名称",
    "taxonomy": {{
        "kingdom": "Animalia",
        "phylum": "Chordata",
        "class": "Actinopterygii",
        "order": "目名",
        "family": "科名",
        "genus": "属名",
        "species": "种名"
    }},
    "visual_features": {{
        "body_shape": "描述体型特征（如纺锤形、侧扁、圆筒形等）",
        "size_range": "成鱼典型大小范围（如10-15cm）",
        "primary_colors": ["主要颜色1", "主要颜色2"],
        "color_patterns": "颜色图案描述（如条纹、斑点、纯色等）",
        "distinctive_markings": ["独特标记1", "独特标记2"],
        "fin_characteristics": {{
            "dorsal_fin": "背鳍特征",
            "tail_fin": "尾鳍特征",
            "pectoral_fins": "胸鳍特征"
        }},
        "eye_features": "眼睛特征（大小、颜色、位置）",
        "mouth_type": "嘴部类型（如端位、上位、下位）"
    }},
    "habitat_appearance": {{
        "typical_background": "典型栖息地背景（如珊瑚礁、岩石、沙底）",
        "water_type": "水体类型（如淡水、海水、汽水）",
        "depth_range": "典型深度范围",
        "geographical_distribution": ["分布区域1", "分布区域2"]
    }}
}}

请确保返回的是有效的JSON格式，包含所有字段。如果某些信息不确定，请基于该属或科的一般特征进行合理推测。"""
        
        return prompt
    
    def call_deepseek_api(self, prompt: str, max_retries: int = 3) -> Optional[Dict]:
        """
        调用DeepSeek API生成响应
        
        Args:
            prompt: 提示词
            max_retries: 最大重试次数
            
        Returns:
            解析后的JSON响应，失败返回None
        """
        for attempt in range(max_retries):
            try:
                # 使用 OpenAI SDK 调用
                response = self.client.chat.completions.create(
                    model="deepseek-chat",
                    messages=[
                        {
                            "role": "system",
                            "content": "你是一个海洋生物学专家，专门研究鱼类分类。请严格按照要求的JSON格式返回信息。"
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=0.7,
                    max_tokens=2000,
                    timeout=30
                )
                
                content = response.choices[0].message.content
                
                # 清理可能的markdown代码块标记
                content = content.strip()
                if content.startswith('```json'):
                    content = content[7:]
                if content.startswith('```'):
                    content = content[3:]
                if content.endswith('```'):
                    content = content[:-3]
                
                # 解析JSON
                metadata = json.loads(content.strip())
                return metadata
                
            except json.JSONDecodeError as e:
                logger.warning(f"JSON解析失败 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(1)
                    
            except Exception as e:
                logger.warning(f"API调用失败 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    # 指数退避
                    wait_time = min(2 ** attempt, 10)  # 最多等待10秒
                    time.sleep(wait_time)
                    
        return None
    
    def generate_metadata_for_class(self, fish_class: str) -> Dict:
        """
        为单个鱼类类别生成元信息
        
        Args:
            fish_class: 鱼类类别名称
            
        Returns:
            包含元信息的字典
        """
        prompt = self.generate_prompt(fish_class)
        metadata = self.call_deepseek_api(prompt)
        
        if metadata is None:
            # 如果API调用失败，返回基础模板
            logger.error(f"无法为 {fish_class} 生成元信息，使用默认模板")
            metadata = {
                "scientific_name": fish_class,
                "common_name": "Unknown",
                "error": "Failed to generate metadata from API"
            }
        else:
            logger.info(f"成功生成 {fish_class} 的元信息")
            
        return metadata
    
    def generate_all_metadata(self, dataset_path: str, output_file: str, 
                            max_workers: int = 5, batch_size: int = 50):
        """
        为所有鱼类类别生成元信息
        
        Args:
            dataset_path: 数据集路径
            output_file: 输出JSON文件路径
            max_workers: 并发线程数
            batch_size: 每批处理的数量（用于定期保存）
        """
        # 提取所有鱼类类别
        print("正在扫描数据集目录...")
        fish_classes = self.extract_fish_classes(dataset_path)
        print(f"找到 {len(fish_classes)} 个鱼类类别")
        
        # 检查是否已有部分结果
        existing_metadata = {}
        if os.path.exists(output_file):
            try:
                with open(output_file, 'r', encoding='utf-8') as f:
                    existing_metadata = json.load(f)
                print(f"已加载 {len(existing_metadata)} 个已存在的元信息")
            except Exception as e:
                logger.warning(f"无法加载现有文件: {e}，将创建新文件")
        
        # 过滤出需要处理的类别
        remaining_classes = [cls for cls in fish_classes if cls not in existing_metadata]
        print(f"需要生成元信息的类别: {len(remaining_classes)}")
        
        if not remaining_classes:
            print("所有类别都已有元信息！")
            return
        
        # 使用线程池并发处理
        all_metadata = existing_metadata.copy()
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 提交任务
            future_to_class = {
                executor.submit(self.generate_metadata_for_class, fish_class): fish_class 
                for fish_class in remaining_classes
            }
            
            # 处理完成的任务
            completed = 0
            with tqdm(total=len(remaining_classes), desc="生成元信息") as pbar:
                for future in as_completed(future_to_class):
                    fish_class = future_to_class[future]
                    try:
                        metadata = future.result()
                        all_metadata[fish_class] = metadata
                        completed += 1
                        pbar.update(1)
                        
                        # 定期保存进度
                        if completed % batch_size == 0:
                            self.save_metadata(all_metadata, output_file)
                            logger.info(f"已保存进度: {len(all_metadata)} 个类别")
                            
                    except Exception as e:
                        logger.error(f"处理 {fish_class} 时出错: {e}")
                        all_metadata[fish_class] = {
                            "scientific_name": fish_class,
                            "error": str(e)
                        }
        
        # 最终保存
        self.save_metadata(all_metadata, output_file)
        print(f"\n完成！已生成 {len(all_metadata)} 个鱼类的元信息")
        
    def save_metadata(self, metadata: Dict, output_file: str):
        """
        保存元信息到JSON文件
        
        Args:
            metadata: 元信息字典
            output_file: 输出文件路径
        """
        # 创建备份
        if os.path.exists(output_file):
            backup_file = f"{output_file}.bak"
            os.replace(output_file, backup_file)
            
        # 保存新文件
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        logger.info(f"元信息已保存到 {output_file}")
    
    def validate_metadata(self, metadata_file: str) -> Dict[str, List[str]]:
        """
        验证生成的元信息质量
        
        Args:
            metadata_file: 元信息文件路径
            
        Returns:
            包含验证结果的字典
        """
        with open(metadata_file, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
        
        results = {
            "total": len(metadata),
            "errors": [],
            "warnings": [],
            "missing_fields": []
        }
        
        required_fields = [
            "scientific_name", "common_name", "taxonomy", 
            "visual_features"
        ]
        
        for fish_class, data in metadata.items():
            # 检查错误
            if "error" in data:
                results["errors"].append(fish_class)
                continue
            
            # 检查必需字段
            for field in required_fields:
                if field not in data:
                    results["missing_fields"].append(f"{fish_class}: missing {field}")
            
            # 检查数据质量
            if data.get("common_name") == "Unknown":
                results["warnings"].append(f"{fish_class}: common_name is Unknown")
                
        return results


def main():
    """主函数"""
    # 配置参数
    DATASET_PATH = "dataset/wildfish"  # 数据集路径
    OUTPUT_FILE = "fish_metadata.json"   # 输出文件
    
    # API密钥配置
    # 方法1: 从环境变量读取（推荐）
    # export DEEPSEEK_API_KEY="your_api_key_here"
    
    # 方法2: 直接传入（仅用于测试）
    API_KEY = "sk-58398b171b744f1d8ab6eb3d9598fd15"
    
    try:
        # 创建生成器实例
        generator = FishMetadataGenerator(api_key=API_KEY)  # 自动从环境变量读取API密钥
        # 或者: generator = FishMetadataGenerator(api_key=API_KEY)
        
        # 生成所有元信息
        generator.generate_all_metadata(
            dataset_path=DATASET_PATH,
            output_file=OUTPUT_FILE,
            max_workers=1,   # 并发线程数，根据API限制调整
            batch_size=5    # 每50个保存一次进度
        )
        
        # 验证结果
        print("\n验证生成的元信息...")
        validation_results = generator.validate_metadata(OUTPUT_FILE)
        
        print(f"\n验证结果:")
        print(f"- 总计: {validation_results['total']} 个类别")
        print(f"- 错误: {len(validation_results['errors'])} 个")
        print(f"- 警告: {len(validation_results['warnings'])} 个")
        print(f"- 缺失字段: {len(validation_results['missing_fields'])} 个")
        
        if validation_results['errors']:
            print(f"\n错误列表: {validation_results['errors'][:5]}...")
        
        # 显示一个成功的示例
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
            
        # 找一个成功的例子
        for fish_class, data in metadata.items():
            if "error" not in data:
                print(f"\n成功示例 - {fish_class}:")
                print(json.dumps(data, ensure_ascii=False, indent=2))
                break
                
    except ValueError as e:
        print(f"配置错误: {e}")
        print("请设置环境变量 DEEPSEEK_API_KEY 或在代码中提供API密钥")
    except Exception as e:
        logger.error(f"程序执行失败: {e}")
        raise


if __name__ == "__main__":
    main()