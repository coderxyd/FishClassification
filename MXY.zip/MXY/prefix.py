import os
import shutil
from PIL import Image
from tqdm import tqdm

def is_image_corrupted(image_path):
    """检查图片是否损坏"""
    try:
        with Image.open(image_path) as img:
            img.verify()  # 验证图片完整性
        return False
    except (IOError, SyntaxError, OSError):
        return True

def replace_corrupted_images(base_dir="dataset/wildfish++"):
    """处理损坏图片的替换"""
    # 遍历所有鱼类目录
    for fish_dir in tqdm(os.listdir(base_dir), desc="Processing species"):
        fish_path = os.path.join(base_dir, fish_dir)
        
        if not os.path.isdir(fish_path):
            continue
        
        # 收集所有符合命名规范的图片
        images = []
        for fname in os.listdir(fish_path):
            if fname.endswith(".jpg") and fname.startswith(fish_dir + "_"):
                try:
                    # 提取图片序号
                    num = int(fname.split("_")[-1].split(".")[0])
                    images.append((num, fname))
                except ValueError:
                    continue
        
        if not images:
            continue
            
        # 按序号排序
        images.sort(key=lambda x: x[0])
        
        # 检查并处理损坏图片
        for i, (num, fname) in enumerate(images):
            img_path = os.path.join(fish_path, fname)
            
            if not is_image_corrupted(img_path):
                continue
                
            print(f"损坏图片: {img_path}")
            
            # 尝试使用前一张图片
            if i > 0:
                prev_num, prev_fname = images[i-1]
                src_path = os.path.join(fish_path, prev_fname)
                if not is_image_corrupted(src_path):
                    shutil.copy2(src_path, img_path)
                    print(f"  └─ 已用前一张图片替换: {prev_fname}")
                    continue
                    
            # 尝试使用后一张图片
            if i < len(images) - 1:
                next_num, next_fname = images[i+1]
                src_path = os.path.join(fish_path, next_fname)
                if not is_image_corrupted(src_path):
                    shutil.copy2(src_path, img_path)
                    print(f"  └─ 已用后一张图片替换: {next_fname}")
                    continue
            
            print(f"  └─ 警告: 无可用相邻图片替换")

if __name__ == "__main__":
    replace_corrupted_images()